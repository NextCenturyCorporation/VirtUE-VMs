/* This file is auto generated, version 201812030624 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201812030624 SMP Sun Jan 6 15:13:14 EST 2019"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "spectre"
#define LINUX_COMPILER "gcc version 8.2.0 (Ubuntu 8.2.0-1ubuntu2~18.04)"
