/* This file is auto generated, version 41-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#41-Ubuntu SMP Wed Oct 10 10:59:38 UTC 2018"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "lcy01-amd64-023"
#define LINUX_COMPILER "gcc version 7.3.0 (Ubuntu 7.3.0-16ubuntu3)"
